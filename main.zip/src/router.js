import { createWebHistory, createRouter } from 'vue-router'
let rts = []

rts = [
  {
    path: '/',
    component: () => import('@main/components/pages/HomePage.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/',
    component: () => import('@gallery/components/pages/Home.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/main/',
    component: () => import('@gallery/components/pages/MainGallery.vue'),
    meta: { transition: 'fade' }
  },

  {
    path: '/gallery/register/',
    component: () => import('@gallery/components/pages/Register.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/tags/',
    component: () => import('@gallery/components/pages/TagList.vue'),
    meta: { transition: 'slide-left' }
  },
  {
    path: '/gallery/tags/:filter',
    component: () => import('@gallery/components/pages/TagDetail.vue'),
    meta: { transition: 'slide-left' }
  },
  {
    path: '/gallery/personal/',
    component: () => import('@gallery/components/pages/Personal.vue'),
    meta: { transition: 'slide-right', requiresAuth: true }
  },
  {
    path: '/gallery/personal/folder/:name',
    component: () => import('@gallery/components/pages/PersonalFolder.vue'),
    meta: { transition: 'slide-right', requiresAuth: true }
  },
  {
    path: '/gallery/personal/folder/create/',
    component: () => import('@gallery/components/pages/PersonalFolderCreate.vue'),
    meta: { transition: 'slide-right', requiresAuth: true }
  },
  {
    path: '/gallery/author/:user',
    component: () => import('@gallery/components/pages/AuthorPage.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/:user/',
    component: () => import('@gallery/components/pages/UserGallery.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/:user/:image/',
    component: () => import('@gallery/components/pages/DetailImage.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/upload/',
    component: () => import('@gallery/components/pages/Upload.vue'),
    meta: { transition: 'fade' }
  },

  {
    path: '/gallery/author/:owner/characters/:character',
    component: () => import('@gallery/components/pages/CharacterPage.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/todo/',
    component: () => import('@gallery/components/pages/TodoPage.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/test/',
    component: () => import('@gallery/components/pages/TestPage.vue'),
    meta: { transition: 'fade' }
  },
  {
    path: '/gallery/comics/:author/:name/',
    component: () => import('@gallery/components/pages/ComicsFolder.vue'),
    meta: { transition: 'slide-right' }
  },
  {
    path: '/gallery/comics/:author/:name/:page/',
    component: () => import('@gallery/components/pages/ComicsDetailPage.vue'),
    meta: { transition: 'slide-right' }
  },
  {
    path: '/gallery/legal/',
    component: () => import('@gallery/components/pages/Legal.vue'),
    meta: { transition: 'slide-right' }
  },

  // ###### End of gallery section ######
  {
    path: '/novel/',
    component: () => import('@novel/components/pages/Home.vue'),
    meta: { transition: 'slide-right' }
  },

  {
    path: '/gallery/:catchAll(.*)/',
    name: 'NotFound',
    component: () => import('@gallery/components/pages/NotFound.vue'),
    meta: {
      requiresAuth: false
    }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes: rts
})

router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth) {
    const token = localStorage.getItem('token')
    if (token) {
      // User is authenticated, proceed to the route
      next()
    } else {
      // User is not authenticated, redirect to login
      next('/gallery/login')
    }
  } else {
    // Non-protected route, allow access
    next()
  }
})

export default router
