<style>
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    background-color: #1e1e1e;
    color: #f0f0f0;
    line-height: 1.6;
}

header {
    background-color: #2c2c2c;
    padding: 1rem;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 1rem;
}

nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

nav a {
    color: #f0f0f0;
    text-decoration: none;
    margin-left: 1rem;
}

nav a:hover {
    text-decoration: underline;
}

.hero,
.section {
    opacity: 0;
    transform: translateY(20px);
    animation: fadeInUp 1s ease forwards;
}

.hero {
    animation-delay: 0.2s;
}

.section {
    animation-delay: 0.4s;
}

@keyframes fadeInUp {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.hero {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    padding: 4rem 1rem;
    background-color: #333;
}

.hero h1 {
    font-size: 2.5rem;
    margin-bottom: 1rem;
}

.hero p {
    font-size: 1.2rem;
    max-width: 600px;
}

.section h2 {
    margin-bottom: 1rem;
}

.gallery,
.comics,
.news {
    margin-top: 2rem;
}

.gallery-images,
.comics-covers {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 1rem;
}

.gallery-images img,
.comics-covers img {
    width: 100%;
    border-radius: 8px;
    object-fit: cover;
}

.news {
    background-color: #292929;
    padding: 2rem;
    border-radius: 10px;
}

.news-article {
    margin-bottom: 1.5rem;
}

.news-article h3 {
    margin-bottom: 0.5rem;
}

footer {
    background-color: #2c2c2c;
    text-align: center;
    padding: 1rem;
    font-size: 0.9rem;
}

@media (min-width: 768px) {
    .hero h1 {
        font-size: 3rem;
    }

    .hero p {
        font-size: 1.4rem;
    }
}
</style>
<template>
    <header>
        <div class="container">
            <nav>
                <div class="logo">Мой Сайт</div>
                <div class="menu">
                    <a href="#">Главная</a>
                    <a href="#about">О нас</a>
                    <a href="#gallery">Галерея</a>
                    <a href="#comics">Комиксы</a>
                    <a href="#news">Новости</a>
                    <a href="#contact">Контакты</a>
                </div>
            </nav>
        </div>
    </header>

    <section class="hero">
        <h1>Добро пожаловать</h1>
        <p>Это главная страница вашего нового сайта в тёмной теме. Всё адаптивно и стильно.</p>
    </section>

    <section class="section" id="about">
        <div class="container">
            <h2>О нас</h2>
            <p>Мы создаём современные и адаптивные сайты в тёмной цветовой гамме.</p>
        </div>
    </section>

    <section class="section gallery" id="gallery">
        <div class="container">
            <h2>Галерея</h2>
            <div class="gallery-images">
                <img src="https://via.placeholder.com/300x200" alt="Галерея 1" />
                <img src="https://via.placeholder.com/300x200" alt="Галерея 2" />
                <img src="https://via.placeholder.com/300x200" alt="Галерея 3" />
                <img src="https://via.placeholder.com/300x200" alt="Галерея 4" />
            </div>
        </div>
    </section>

    <section class="section comics" id="comics">
        <div class="container">
            <h2>Комиксы</h2>
            <div class="comics-covers">
                <img src="https://via.placeholder.com/150x220" alt="Комикс 1" />
                <img src="https://via.placeholder.com/150x220" alt="Комикс 2" />
                <img src="https://via.placeholder.com/150x220" alt="Комикс 3" />
            </div>
        </div>
    </section>

    <section class="section news" id="news">
        <div class="container">
            <h2>Новости проекта</h2>
            <div class="news-article">
                <h3>Запуск новой версии сайта</h3>
                <p>Мы выпустили новую версию нашего сайта с улучшенной тёмной темой и адаптивной версткой!</p>
            </div>
            <div class="news-article">
                <h3>Обновление галереи</h3>
                <p>Теперь в галерее больше изображений и поддержка мобильных устройств.</p>
            </div>
        </div>
    </section>
</template>