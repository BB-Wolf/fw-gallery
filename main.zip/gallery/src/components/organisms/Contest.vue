<template>
    <section id="contest">
        <div class="contest-title h2">Конкурс на что-то</div>
        <div class="contest-container">
            <div class="contest-body">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum voluptas dignissimos
                eos vel, saepe, alias quae cumque corporis, nemo hic totam dolorem ex optio quo veritatis suscipit? Ab,
                quod natus.</div>
            <NewGallery galleryUrl="/gallery/contest/" galleryType="contest" galleryTitle="" />
        </div>
    </section>
</template>

<script setup>
import NewGallery from '../organisms/NewGallery.vue';
</script>

<style scoped>
.contest-body {
    color: #fff;
    padding-bottom: 20px;
}
</style>