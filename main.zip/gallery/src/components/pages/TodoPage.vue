<template>
    <div class="container">
        <ul>
            <li>Удаление полей в профиле</li>
            <li>Поиск</li>
            <li>Статистика</li>
            <li>Интерфейс уведомлений</li>
            <li>подписка на пользователя</li>
            <li>Kafka</li>
            <li>Проработать мобильную загрузку фото</li>
            <li>Автопостинг в другие сети</li>
            <li>Конкурсный блок</li>
            <li>Комментарии</li>
            <li>Фильтр по палитре</li>
            <li>Обработка пустых страниц</li>
        </ul>
    </div>
</template>

<style scoped>
ul {
    display: flex;
    flex-direction: column;
    color: white;
}
</style>