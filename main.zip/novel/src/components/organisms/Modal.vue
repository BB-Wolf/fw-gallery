<template>
    <div id="" class="modal">
        <div class="modal-title"></div>
        <div class="modal-body"></div>
        <div class="modal-foot"></div>
    </div>
</template>