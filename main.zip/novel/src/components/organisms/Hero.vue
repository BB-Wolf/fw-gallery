<script setup>
import Image from '../atoms/Image.vue';
</script>

<template>
    <div class="hero">
        <div>
            <!----
            <Image imageSrc="" imageTitle="12" imageAlt="12"></Image>
            -->
        </div>
    </div>
</template>
