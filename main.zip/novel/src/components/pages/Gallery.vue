<script setup>
import Tags from '../organisms/Tags.vue';
import NewGallery from '../organisms/NewGallery.vue';

</script>

<template>
    <div>
        <Tags />
        <div class="gallery-container">
            <NewGallery galleryTitle="Новое" />
        </div>
    </div>
</template>

<style scoped></style>