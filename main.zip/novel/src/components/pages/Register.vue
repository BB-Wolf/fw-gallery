<template>
    <div class="container">
        <div class="h1"> Регистрация</div>
        <div class="profile-container">
            <h2>User Profile</h2>

            <!-- Profile Section -->
            <div class="profile-section">
                <!-- User Data -->
                <div class="user-data">
                    <!-- Username -->
                    <label for="username">Username</label>
                    <input type="text" id="username" value="john_doe" required>

                    <!-- Email -->
                    <label for="email">Email</label>
                    <input type="email" id="email" value="john_doe@example.com" required>
                </div>
            </div>
        </div>

    </div>
</template>


<style scoped>
.container {
    margin: 0 auto;
    max-width: 100%;
    padding: 0px 20px;
}
</style>